-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 23, 2019 at 11:33 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lba_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `Id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `des` varchar(50) NOT NULL,
  `price` varchar(50) NOT NULL,
  `tim` varchar(50) NOT NULL,
  `offer` varchar(50) NOT NULL,
  `img` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `lat` varchar(50) NOT NULL,
  `log` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `images` text NOT NULL,
  `phno` varchar(20) NOT NULL,
  `from_date` varchar(20) NOT NULL,
  `to_date` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`Id`, `name`, `type`, `des`, `price`, `tim`, `offer`, `img`, `location`, `lat`, `log`, `uname`, `images`, `phno`, `from_date`, `to_date`) VALUES
(31, 'starbucks', 'Job', 'We are looking for a waiter ', '10', 'opens at 11AM', 'Flexible timings', '', 'prairie view ', '30.0881522', '-95.9850969', 'anitha', '', '', '', ''),
(38, 'Chevron ', 'Job', 'Hiring helpers.. ', '10', '10PM-5AM', 'N', '', 'Katy, houston ', '29.79264894732902', '-95.6887936592102', 'anitha', '', '', '', ''),
(30, 'Pizza hut ', 'Restaurant', 'fresh pizzas ', '25', 'opens at 11AM', 'Buy 1 get 2 @20%off ', '', 'Sugarland, Houston ', '29.5886016', '95.5981931', 'anitha', '', '', '', ''),
(51, 'Subway', 'Resturant', 'Authentic Indian restaurant, hyderabadi biryani ', '$30', 'opens at 11AM', 'Happy hour- 5PM-7PM', 'Screenshot (2).png', 'prairie view ', '30.087621', '-95.988419', 'anitha', '', '', '', ''),
(36, 'HydMoonCafe', 'Resturant', 'Anitha Des1', '44', '22:00PM', '1', '', 'Texas1', '17.39932247577607', '78.49960880858725', 'anitha', '', '', '', ''),
(37, 'Texas childrens hospital ', 'Job', 'We are looking for a receptionist ', '30', 'opens at 8AM', 'Flexible timings', '', 'Katy, houston ', '29.787062313026084', '-95.691819190979', 'anitha', '', '', '', ''),
(32, 'Chic-fil-a', 'Restaurant', 'Fresh sandwich', '5', 'opens at 8AM', '30% off for students ', '', 'prairie view ', '30.09267497459101', '-95.99119663238525', 'anitha', '', '', '', ''),
(33, 'Subway ', 'Restaurant', 'Build your own sandwich', '10', 'Opens at 7AM ', '20% off for students only today ', '', 'prairie view ', '30.0874022288395', '-95.98849296569824', 'anitha', '', '', '', ''),
(34, 'Biryani n Grill', 'Restaurant', 'Authentic Indian restaurant, hyderabadi biryani ', '30', '12AM-2PM, 5PM-10PM', 'Happy hour- 5PM-7PM', '', 'Dairy Ashford ', '29.748068238229145', '-95.60516238212585', 'anitha', '', '', '', ''),
(35, 'Jinya Ramen bar ', 'Resturant', 'Outdoor seating. Comfort food ', '40', 'opens at 11AM', 'Happy hour food', '', 'Katy fwy ', '29.786349994738547', '-95.74515223503113', 'anitha', '', '', '', ''),
(45, 'starbucks', 'Resturant', 'We are looking for a waiter ', '10', '12AM-2PM, 5PM-10PM', 'Happy hour- 5PM-7PM', 'Screenshot (4).png', 'Sugarland, Houston ', '29.748068238229145', '-95.99119663238525', 'anitha', '', '', '', ''),
(44, '123', '123', '123', '123', '132', '123', '', '123', '123', '123', 'anitha', '', '', '', ''),
(50, 'starbucks', 'Job', 'We are looking for a waiter ', '$10', 'opens at 11AM', 'Happy hour- 5PM-7PM', 'Screenshot (3).png', 'Katy, houston ', '30.0874022288395', '75334', 'anitha', '', '', '', ''),
(52, '105640', 'Resturant', 'Des', '$11', '22:00PM', '121', 'ic_launcher-web.png', '344', '28.642388510950006', '-98.95385781250002', 'anitha', '', '', '', ''),
(53, 'HydMoonCafe', 'Job', 'asd', '$11', '22:00PM', 'sasd', 'ic_launcher-web.png', 'sdsd', '28.101057308409395', '-97.32788125000002', 'anitha', '', '', '', ''),
(54, '105640', 'Mall', 'asd', '$11', '22', 'sasd', 'ic_launcher-web.png', 'Texas', '29.71668064701918', '-101.19506875000002', 'sam', '', '', '', ''),
(55, 'asc', 'Job', 'as', '$1', '22:00PM', 'sasd', 'Array', '344', '29.33429758767931', '-103.41430703125002', 'sam', '', '', '', ''),
(56, '105640', 'Job', 'Des', '$11', '22', 'sasd', 'Array', 'sdsd', '31.83089843709917', '-103.15063515625002', 'sam', '', '', '', ''),
(57, 'HydMoonCafe', 'Resturant', 'Des', '$1', '22:00PM', 'sasd', '', '344', '28.950475029806835', '-102.60131875000002', 'sam', '', '', '', ''),
(58, 'HydMoonCafe', 'Resturant', 'Des', '$1', '22:00PM', 'sasd', '', 'asdasd', '30.211607586785362', '-103.61206093750002', 'sam', '', '', '', ''),
(75, 'anu', 'Resturant', 'fresh pizzas ', '$10', 'opens at 11AM', 'Flexible timings', 'Screenshot (3).png', 'Katy, houston ', '29.449164185013608', '-102.73315468750002', 'Anitha', 'Screenshot (3).png', '7123', '11-Nov-2018', '12-Nov 2019 '),
(67, '105640', 'Resturant', 'sdasd', '$1', '22:00PM', 'sasd', 'Screenshot_20191114-144227.png', 'Texas1', '29.184237840242222', '-100.60678521118166', 'sam', 'Screenshot_20191114-144227.png', '', '', ''),
(66, 'SaiBaba', 'Resturant', 'sai baba template', '$3', '22:00PM', 'sasd', '5-ganguli.png', 'Hyd Sundaraya', '17.39881429160421', '78.49968552589417', 'sam', '3-kcr-jagan.png,4-modi.png,5-ganguli.png', '', '', ''),
(72, 'HydMoonCafe', 'Resturant', 'Des', '$1', '22:00PM', '1', 'ic_p.png', 'asdasd', '27.53841293246311', '-92.87241021118166', 'sam', 'ic_p.png', '1234567890', 'dfsdf', 'sf'),
(74, 'Chic-fil-a', 'Resturant', 'Famous for made-to-order fresh pizzas', '$30', '12AM-2PM, 5PM-10PM', 'Flexible timings', 'Screenshot (3).png', 'Katy, houston ', '30.0874022288395', '-95.9850969', 'Anitha', 'Screenshot (3).png', '878767565', '11-Nov-2018', '12-Nov 2019 ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=76;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
