-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 23, 2019 at 11:35 AM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lba_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `pass` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Id`, `fname`, `lname`, `phone`, `uname`, `email`, `pass`) VALUES
(1, 'raf', 'Nadakuditi', '8790604717', 'admin', 'bokmyproject@gmail.com', '123'),
(2, 'raf', 'Nadakuditi', '8790604717', 'admin1', 'bokmyproject@gmail.com', '321'),
(3, 'sam', 'test', '90909080', 'sam', 'saho@gmail.com', '123'),
(4, 'Anitha', 'Palusa', '7138351612', 'anitha123', 'anitharai669@gmail.com', 'WdYr8LyD'),
(5, 'Anitha', 'Rai', '898989', 'anitha', 'a@gmail.com', '123'),
(7, 'Ravinder', 'Malela', '1234567', 'ravinder123', 'apalusa@student.pvamu.edu', '123456'),
(8, 'adskf', 'dnksdn', '333333', '1234', 'adkfnkdf', 'saddff'),
(9, 'Anitha`', 'm', '77777', '12345', 'adkfnkdf', '65657'),
(10, 'Anitha', 'Palusa', '9987654332', 'anitham', 'ravinder.4143@gmail.com', '6765565456'),
(11, 'Anitha', 'Malela', '4565867989', 'Anitha1', 'adkfnkdf', '233445'),
(13, 'ravi', 'Nadakuditi', '8790604717', 'ravi', 'ravi.nadakuditi@gmail.com', 'Ravi@123'),
(12, 'Anitha', 'Palusa', '3446678', 'Anithaw', 'adkfnkdf', '154345'),
(14, 'raj', 'raj', '12222', 'raj', 'raj@gg.com', 'Hari1039$'),
(15, 'raj', 'raj', '222-333-4444', 'sam1', 'rraju1039@gmail.com', 'Hari1039$'),
(16, 'a', 'dc', '713-835-1612', 'ani8', '24hjigug@gmail.com', 'Anitha123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `uname` (`uname`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
