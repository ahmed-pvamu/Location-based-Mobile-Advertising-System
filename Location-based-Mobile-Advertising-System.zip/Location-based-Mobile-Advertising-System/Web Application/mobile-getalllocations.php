<?php
include 'config.php';
$con=mysql_connect($hostname, $username, $password) OR DIE ("Unable to connect to database! Please try again later.");
            mysql_select_db($dbname);
	    $query = "SELECT * from jobs;";
	    $retval = mysql_query($query);
	    if(! $retval )
	    {
	    echo 'No data'.mysql_error();
	    }
	    else
	    {
				$rows = array();
				while($row = mysql_fetch_assoc($retval)) 
				{
					$rows[] = array('Id' => $row['Id'],'name' => $row['name'],'des' => $row['des'],'type' => $row['type'],'lat' => $row['lat'],'log' => $row['log'],'price' => $row['price'],'tim' => $row['tim'],'offer' => $row['offer'],'img' => $row['img'],'location' => $row['location']);
				}
				echo json_encode($rows);
	  }
?>