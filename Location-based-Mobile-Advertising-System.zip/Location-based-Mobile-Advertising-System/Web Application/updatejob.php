

<?php session_start();
if(isset($_SESSION['un'])=="")
{
    header('Location:login.html');
}
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled and minified CSS -->
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->

<!-- jQuery library -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->

<!-- Latest compiled JavaScript -->
<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->


<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
      <link rel="shortcut icon" href="http://stepwaysolutions.com/images/fav.png" type="image/x-icon" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3">
    <title>Anitha Project</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
        crossorigin="anonymous">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">


    <link href="style.css" rel="stylesheet">


    <style>
    
    .page-link {
    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #ffffff;
    background-color: #212529;
    border: 1px solid #dee2e6;
}

.page-item.active .page-link {
    z-index: 1;
    color: #fff;
    background-color: #6c757d;
    border-color: #6c757d;
}
    
        .sidebar-wrapper .sidebar-header .user-pic img {
            object-fit: cover;
            height: 50px;
            width: 100%;
        }

        .sidebar.sidebar-bg {
            background-image: url(bg1.jpg);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        
        .card {
    position: relative;
    padding: 20px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: .25rem;
}

.modal .modal-dialog {
		max-width: 600px;
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}	
	.modal form label {
		font-weight: normal;
	}
	
	td
	{
	    padding-left :12px;
	    padding-top :10px;
	    padding-bottom :10px;
	}
	
	th
	{
	    padding: .25rem .75rem;
    font-size: .975rem;
    line-height: 1.5;
    border-radius: 0px;
    color: #fff;
    background-color: #343a40;
    border-color: #343a40;
       
    font-weight: 400;
   
    white-space: nowrap;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 1px solid transparent;
   
    font-size: 1rem;
    line-height: 1.5;
   
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	}
    </style>


</head>

<body>
<?php
function phpAlert($msg) {
    echo '<script type="text/javascript">
    alert("' . $msg . '")</script>';
}
?>

<?php
include 'config.php';


    $id=$_POST['id']; 
 $name=$_POST['name'];
 $type=$_POST['type'];
 $des=$_POST['des'];
 $p=$_POST['price'];
 $tim=$_POST['tim'];
 $offer=$_POST['offer'];
 //$img=$_POST['img'];
 $loc=$_POST['loc'];
 $lat=$_POST['lat'];
 $log=$_POST['log'];
 
 
  //echo $name;
   //echo $id;
  
    $sql = "update jobs set name='$name', type='$type', des='$des', price='$p', tim='$tim', offer='$offer', location='$loc', lat='$lat', log='$log' where Id='$id'  ";
    

    if ($conn->query($sql) === TRUE) {
      // echo "Section Added successfully";
       echo "Successfully Updated"  ;
       // header('Location:home.php');
       // window.open("home.php");
    } else {
      
        phpAlert(  "Something Went Wrong. please contact Admin....!"  );
    
    }
    
    $conn->close();


?>


<a href="home.php">Go Back</a>

</body>
</html>