<?php
function phpAlert($msg) {
    echo '<script type="text/javascript">
    alert("' . $msg . '")</script>';
}
?>

<?php
include 'config.php';


 $name=$_POST['name'];
 $type=$_POST['type'];
 $des=$_POST['des'];
 $p=$_POST['price'];
 $tim=$_POST['tim'];
 $offer=$_POST['offer'];
 $img=$_POST['img'];
 $loc=$_POST['location'];
 $lat=$_POST['lat'];
 $log=$_POST['log'];
  
  //  $sql = "INSERT INTO jobs (name, 
    //type,des,price,tim,offer,img,locaton,lat,log)
    //VALUES ('$name','$type','$des','$p','$tim','$offer','$img','$loc','$lat','$log')";
    
    
     $sql = "INSERT INTO jobs (name, 
    type,des,price,tim,offer,img,location,lat,log)
    VALUES ('$name','$type','$des','$p','$tim','$offer','img','$loc','$lat','$log')";
 
    if ($conn->query($sql) === TRUE) {
       // echo "Section Added successfully";
        header('Location:home.php');
    } else {
      
        phpAlert(  "Something Went Wrong. please contact Admin....!"  );
    
    }
    
    $conn->close();

?>

