<?php
include 'config.php';



    $fn=$_POST['fn'];
    $ln=$_POST['lname'];

      $phone=$_POST['phone'];
    $email=$_POST['email'];
    $un=$_POST['un'];
  
     $pass=$_POST['pass'];
  
    $sql = "INSERT INTO register (fname, 
    lname,phone,email,uname,pass)
    VALUES ('$fn','$ln','$phone','$email','$un','$pass')";
    
    if ($conn->query($sql) === TRUE) {
       // echo "Section Added successfully";
        header('Location:login.html');
    } else {
      
        echo "Something Went Wrong. please contact Admin....!"  ;
    
    }
    
    $conn->close();












?>