<?php session_start();
if(isset($_SESSION['un'])=="")
{
    header('Location:login.html');
}
?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<!-- Latest compiled and minified CSS -->
<!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">-->

<!-- jQuery library -->
<!--<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>-->

<!-- Latest compiled JavaScript -->
<!--<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->


<!------ Include the above in your HEAD tag ---------->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
      <link rel="shortcut icon" href="http://stepwaysolutions.com/images/fav.png" type="image/x-icon" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Responsive sidebar template with sliding effect and dropdown menu based on bootstrap 3">
    <title>Anitha Project</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm"
        crossorigin="anonymous">
    <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet">


    <link href="style.css" rel="stylesheet">


    <style>
    
    .page-link {
    position: relative;
    display: block;
    padding: .5rem .75rem;
    margin-left: -1px;
    line-height: 1.25;
    color: #ffffff;
    background-color: #212529;
    border: 1px solid #dee2e6;
}

.page-item.active .page-link {
    z-index: 1;
    color: #fff;
    background-color: #6c757d;
    border-color: #6c757d;
}
    
        .sidebar-wrapper .sidebar-header .user-pic img {
            object-fit: cover;
            height: 50px;
            width: 100%;
        }

        .sidebar.sidebar-bg {
            background-image: url(bg1.jpg);
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        
        .card {
    position: relative;
    padding: 20px;
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: vertical;
    -webkit-box-direction: normal;
    -ms-flex-direction: column;
    flex-direction: column;
    min-width: 0;
    word-wrap: break-word;
    background-color: #fff;
    background-clip: border-box;
    border: 1px solid rgba(0,0,0,.125);
    border-radius: .25rem;
}

.modal .modal-dialog {
		max-width: 600px;
	}
	.modal .modal-header, .modal .modal-body, .modal .modal-footer {
		padding: 20px 30px;
	}
	.modal .modal-content {
		border-radius: 3px;
	}
	.modal .modal-footer {
		background: #ecf0f1;
		border-radius: 0 0 3px 3px;
	}
    .modal .modal-title {
        display: inline-block;
    }
	.modal .form-control {
		border-radius: 2px;
		box-shadow: none;
		border-color: #dddddd;
	}
	.modal textarea.form-control {
		resize: vertical;
	}
	.modal .btn {
		border-radius: 2px;
		min-width: 100px;
	}	
	.modal form label {
		font-weight: normal;
	}
	
	td
	{
	    padding-left :12px;
	    padding-top :10px;
	    padding-bottom :10px;
	}
	
	th
	{
	    padding: .25rem .75rem;
    font-size: .975rem;
    line-height: 1.5;
    border-radius: 0px;
    color: #fff;
    background-color: #343a40;
    border-color: #343a40;
       
    font-weight: 400;
   
    white-space: nowrap;
    vertical-align: middle;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    border: 1px solid transparent;
   
    font-size: 1rem;
    line-height: 1.5;
   
    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
	}
    </style>


</head>

<body>
    
   <?php include 'topnav.php' ?>
    
    <div class="page-wrapper chiller-theme toggled">
        <!--<a id="show-sidebar" class="btn btn-sm btn-dark" href="#">-->
        <!--    <i class="fas fa-bars"></i>-->
        <!--</a>-->
       
        <!-- sidebar-wrapper  -->
        <main class="page-content">
               
          
            
            <div class="container-fluid">
                <h2>Welcome To Dashbaord  <?php 
                            
                            if(isset($_SESSION['un']) )
{
$name=$_SESSION['un'];


echo "<strong>$name</strong>" ;
}
                            
                     
                            ?></h2>
                <hr>
                <div class="row">
                     
             
                </div>
               
                
                
                <div class="row card">
                    <div class="col-xs-12 col-sm-6 col-md-12 col-lg-12">
                      



<button class="btn btn-dark btn-sm" data-toggle="modal" data-target="#addjobs"><span class="glyphicon glyphicon-plus">+ </span>Add Jobs</button>



<!--<a href="addrow.php?section_name=<?php $sectionname=$_GET['section_name'];echo trim($sectionname);?>">-->
<!--<button class="btn btn-dark btn-sm"><span class="glyphicon glyphicon-plus">+ </span>Row</button>-->
<!--</a>-->
<!--<button class="btn btn-dark btn-sm" ><span class="glyphicon glyphicon-plus">+</span> Students</button>-->

<span><input class="form-control" id="myInput" type="text" placeholder="Search location.."></span>
        




<p style="color:red" id="msg"></p>


<?php
function phpAlert($msg) {
    echo '<script type="text/javascript">
    alert("' . $msg . '")</script>';
}
?>

<?php
include 'config.php';

if(isset($_POST['submit']))
{
    $file = $_FILES['f'];
$file_name = $file['name'];
$file_type = $file ['type'];
$file_size = $file ['size'];
$file_path = $file ['tmp_name'];
if(move_uploaded_file ($file_path,'images/'.$file_name));
    
    
    
 $dname=$_POST['n'];
 $type=$_POST['type'];
 $des=$_POST['des'];
 $p=$_POST['price'];
 $tim=$_POST['tim'];
 $offer=$_POST['offer'];
 //$img=$_POST['img'];
 $loc=$_POST['location'];
 $lat=$_POST['lat'];
 $log=$_POST['log'];
 
//  alert($dname);
  
    $sql = "INSERT INTO jobs (name, 
    type,des,price,tim,offer,img,location,lat,log)
    VALUES ('$dname','$type','$des','$p','$tim','$offer','$file_name','$loc','$lat','$log')";
   // echo $dname;
    
    //  $sql = "INSERT INTO jobs (name, 
    // type,des,price,tim,offer,img,location,lat,log)
    // VALUES ('123','123','123','123','132','123','$file_name','123','123','123')";
 

 
    if ($conn->query($sql) === TRUE) {
      // echo "Section Added successfully";
        header('Location:home.php');
    } 
    else {
      
        phpAlert(  "Something Went Wrong. please contact Admin....!"  );
    
    }
    
    $conn->close();

}
?>




<!-- Modal -->
<div id="addjobs" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
          <h4 class="modal-title">Add Job Information</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        
      </div>
      <div class="modal-body">
      

      <form action="" method="POST" role="form">
   
   <div class="row">
      
          
          <div class="col-sm-6">
                <div class="form-group">
        <label for="n">Name</label>

       <input type='text' name='n' class='form-control' 
        id='n' placeholder="Enter Name"  required>
       </div>
       </div>
       
       
       <div class="col-sm-6">
     <div class="form-group">
        <label for="type">Type</label>
        <!--<input type="text" name="type" class="form-control" -->
        <!--id="type" placeholder="Enter type" required>-->
        <!--</div>-->
        
        <select name="type" class="form-control" 
        id="type">
            <option>Resturant</option>
            <option>Job</option>
            <option>Mall</option>
            <option>Store</option>
            
        </select>
        
        </div>
        
    </div>

       
   </div>
   
     
        <div class="row">
      
          
          <div class="col-sm-6">
    <div class="form-group">
        <label for="des">Description</label>
        <input type="text" name="des" class="form-control" 
        id="des" placeholder="Enter Description" required>
    </div>
    </div>
    
    
 <div class="col-sm-6">
    <div class="form-group">
        <label for="price">Price</label>
        <input type="number" name="price" class="form-control" 
        id="price" placeholder="Enter Price" required>
    </div>
    </div>
    
    
    </div>
    
    
          <div class="row">
                   <div class="col-sm-6">
     <div class="form-group">
        <label for="tim">Time</label>
        <input type="text" name="tim" class="form-control" 
        id="tim" placeholder="Enter Time" required>
    </div>
    </div>
         <div class="col-sm-6">
     <div class="form-group">
        <label for="offer">Offer</label>
        <input type="text" name="offer" class="form-control" 
        id="offer" placeholder="Enter Offer" required>
    </div>
    </div>
    </div>
    
    
     <div class="row">
                   <div class="col-sm-6">
     <div class="form-group">
        <label for="file">Place Image</label>
        <!--<input type="text" name="img" class="form-control" -->
        <!--id="img" placeholder="Enter Image" required>-->
        
        
        <input type="file" name="f" id="f" class="form-control" 
        id="file"/>
        
        
    </div>
    </div>
    
     
                   <div class="col-sm-6">
    
     <div class="form-group">
        <label for="loc">Location</label>
        <input type="text" name="location" class="form-control" 
        id="loc" placeholder="Enter Location" required>
    </div>
    </div>
    </div>
    <div class="row">
                   <div class="col-sm-12">
                       <div id="googleMap" style="width:500px;height:400px;"></div>
                       <!-- Map Start-->
                       <script>
var map;
function myMap() {
    
var mapProp= {
  center:new google.maps.LatLng(31.00586227279572,-99.61303750000002),
  zoom:5,
};
 map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

map.addListener('click', function (locationdata) {
  document.getElementById("lat").value =locationdata.latLng.lat();
  document.getElementById("log").value =locationdata.latLng.lng();
  //alert(locationdata.latLng.lat());
  /*
  var goldenGatePosition = {lat: locationdata.latLng.lat(),lng: locationdata.latLng.lng()};
	var marker = new google.maps.Marker({
			position: goldenGatePosition,
			map: map,
			title: ''
			});*/
			placeMarker(locationdata.latLng);
});

}

var marker;

function placeMarker(location) {
 if ( marker ) {
   marker.setPosition(location);
 } else {
  marker = new google.maps.Marker({
  position: location,
  map: map
  });
 }
}

</script>

<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCmVU7RG7phKtofY6IGIKVJYiI4TuSjlLY&callback=myMap&language=en"></script>
                       <!-- Map End -->
                       </div>
                       </div>
    
     <div class="row">
                   <div class="col-sm-6">
    
     <div class="form-group">
        <label for="lat">Latitude</label>
        <input type="text" name="lat" class="form-control" 
        id="lat" placeholder="Enter Latitude" required>
    </div>
    </div>
    
    
                   <div class="col-sm-6">
    
     <div class="form-group">
        <label for="log">Longitude</label>
        <input type="text" name="log" class="form-control" 
        id="log" placeholder="Enter Longitude" required>
    </div>
    </div>
    </div>
    
    <!-- <div class="form-group">-->
    <!--    <label for="age">Age</label>-->
    <!--    <input type="text" name="age" class="form-control" -->
    <!--    id="age" placeholder="Enter Age" required>-->
    <!--</div>-->


    

    <button type="submit" name="submit" class="btn btn-dark">Submit</button>
</form>



      </div>
      <div class="modal-footer">
       </div>
    </div>

  </div>
</div>







<table align=center style="width:100%;margin:10px" class="table-hover" id="myTable">
    <tr>
       <th>Id</th>
        <th>Name</th>
        <th>Type</th>
        <th>Description</th>
        <th>Price</th>
      
        <th>Time</th>
        <th>Offer</th>
        <th>Image</th>
        <th>Location</th>
        <th>Lat</th>
        <th>Log</th>
        <th>Edit</th>
    </tr>
    
<?php

include 'config.php';

 if (isset($_GET['pageno'])) {
            $pageno = $_GET['pageno'];
        } else {
            $pageno = 1;
        }
        $no_of_records_per_page = 10;
        $offset = ($pageno-1) * $no_of_records_per_page;



$sql = "SELECT * FROM jobs order by Id desc ";
$result = $conn->query($sql);
$i = 1;

$total_pages_sql = "SELECT COUNT(*) FROM jobs";
        $result = mysqli_query($conn,$total_pages_sql);
        $total_rows = mysqli_fetch_array($result)[0];
        $total_pages = ceil($total_rows / $no_of_records_per_page);

        $sql = "SELECT * FROM jobs order by Id desc LIMIT $offset, $no_of_records_per_page";
        $res_data = mysqli_query($conn,$sql);
        while($row = mysqli_fetch_array($res_data)){
            //here goes the data
            
            
        echo "<tr>
        
         <td> 
        
         ".$row['Id']."
          </td>
        <td> ".$row['name']."</td>
        <td> ".$row['type']."</td>
        <td> ".$row['des']."</td>
         <td> ".$row['price']."</td>
          <td> ".$row['tim']."</td>
        <td> ".$row['offer']."</td>
          <td>  ".$row['img']."</td>
          <td> ".$row['location']."</td>
        <td> ".$row['lat']."</td>
       <td> ".$row['log']."</td>

        <td> 
         
        
        <a href='#'>
        <button class='btn btn-warning btn-sm' data-toggle='modal' data-target='#".$row['Id']."' ><span class='glyphicon glyphicon-edit'> <img src='images/update.png'  style='width:20px'/></span>
       
        </button>
        </a>
        
        
        <div id='".$row['Id']."' class='modal fade' role='dialog'>
  <div class='modal-dialog'>

    
    <div class='modal-content'>
      <div class='modal-header'>
      <h4 class='modal-title'>Update</h4>
        <button type='button' class='close' data-dismiss='modal'>&times;</button>
        
      </div>
      <div class='modal-body'>
        
       
      <form action='updatejob.php' method='POST' role='form'>
      
      
         <div class='row'>
      
          
          <div class='col-sm-6'>
          
    <button type='submit' name='submit' class='btn btn-primary'>Submit</button>
          </div>
          
          </div>
      
      
   
   <div class='row'>
      
          
          <div class='col-sm-6'>
        
        <div class='form-group'>
        <label for='id'>Id</label>
        <input type='text' name='id' value='".$row['Id']."' readonly class='form-control' 
        id='id'  required>
    </div>
    </div>
     <div class='col-sm-6'>
    <div class='form-group'>
        <label for='name'>Name</label>
        <input type='text' name='name' value='".$row['name']."'  class='form-control' 
        id='name'  required>
    </div>
    </div>
    
    </div>
     <div class='row'>
      
          
          <div class='col-sm-6'>
        
        <div class='form-group'>
        <label for='type'>Type</label>
        <input type='text' name='type' value='".$row['type']."'  class='form-control' 
        id='type'  required>
    </div>
    </div>
     <div class='col-sm-6'>
    <div class='form-group'>
        <label for='des'>Description</label>
        <input type='text' name='des' value='".$row['des']."'  class='form-control' 
        id='des'  required>
    </div>
    </div>
    
    </div>
    
     <div class='row'>
      
          
          <div class='col-sm-6'>
        
        <div class='form-group'>
        <label for='price'>Price</label>
        <input type='text' name='price' value='".$row['price']."'  class='form-control' 
        id='price'  required>
    </div>
    </div>
     <div class='col-sm-6'>
    <div class='form-group'>
        <label for='tim'>Time</label>
        <input type='text' name='tim' value='".$row['tim']."'  class='form-control' 
        id='tim'  required>
    </div>
    </div>
    
    </div>
    
      <div class='row'>
      
          
          <div class='col-sm-6'>
        
        <div class='form-group'>
        <label for='offer'>Offers</label>
        <input type='text' name='offer' value='".$row['offer']."'  class='form-control' 
        id='offer'  required>
    </div>
    </div>
     <div class='col-sm-6'>
    <div class='form-group'>
        <label for='loc'>Location</label>
        <input type='text' name='loc' value='".$row['location']."'  class='form-control' 
        id='loc'  required>
    </div>
    </div>
    
    </div>
    
     <div class='row'>
      
          
          <div class='col-sm-6'>
        
        <div class='form-group'>
        <label for='lat'>Latitude</label>
        <input type='text' name='lat' value='".$row['lat']."'  class='form-control' 
        id='lat'  required>
    </div>
    </div>
    
     <div class='col-sm-6'>
    <div class='form-group'>
        <label for='log'>Longitude</label>
        <input type='text' name='log' value='".$row['log']."'  class='form-control' 
        id='log'  required>
    </div>
    </div>
    
    
  
    </div>
    
   
    

    
        
      </div>
      </form>
    </div>

  </div>
</div>
        
        
        
        
        <a href='delete.php?id=".$row['Id']."'>
        <button class='btn btn-default btn-sm'><span class='glyphicon glyphicon-delete'>
         <img src='images/del.png'  style='width:20px'/>
        </span>
        </button>
        </a>
        
        
       
        </td>


       
        </tr>";
  $i++;
        }
        
// if ($result->num_rows > 0) {
//     // output data of each row
//     while($row = $result->fetch_assoc()) {
    
    

//         echo "<tr>
        
//          <td>  $i
//           </td>
//         <td> ".$row['name']."</td>
//         <td> ".$row['sid']."</td>
//         <td> ".$row['phone']."</td>
//          <td> ".$row['email']."</td>
//           <td> ".$row['fee']."</td>
//         <td> ".$row['dat']."</td>
        
       

//         <td> 
//         <a href='#'>
//         <button class='btn btn-warning btn-sm'><span class='glyphicon glyphicon-edit'> <img src='Images/update.png'  style='width:20px'/></span></button>
//         </a>
//         <a href='deletestudent.php?id=".$row['Id']."'>
//         <button class='btn btn-default btn-sm'><span class='glyphicon glyphicon-delete'>
//          <img src='Images/del.png'  style='width:20px'/>
//         </span>
//         </button>
//         </a>
        
        
       
//         </td>


       
//         </tr>";
//   $i++;
   
//     }
// } else {
//     echo "0 results";
// }


$conn->close();
?>
    
    
</table>


                  




<!--/.pagenation-->

<div style='margin:10px 110px 0px 0px;text-align:right'>
<strong >Page <?php echo $pageno." of ".$total_pages; ?></strong>
</div>
<div style='margin:-10px 25px 0px 35%; text-align:center'>
<ul class="pagination">
        <li class="page-item"><a class="page-link" href="?pageno=1">First</a></li>
        <?php
if ($total_pages <= 50){   
 for ($counter = 1; $counter <= $total_pages; $counter++){
 if ($counter == $pageno) {
 echo "<li class='active page-item'><a class='page-link'>$counter</a></li>"; 
         }else{
        echo "<li class='page-item'><a class='page-link' href='?pageno=$counter'>$counter</a></li>";
       }
    }
  }
?>
  <li class="page-item"><a class="page-link" href="?pageno=<?php echo $total_pages; ?>">Last</a></li>
  </ul>
</div>



                            <div class="card-body text-center">
                                
    <!--                           <ul class="pagination">-->
    <!--     <li ><a  href="?pageno=1">First</a></li>-->
    <!--    <li class="<?php if($pageno <= 1){ echo 'disabled'; } ?>">-->
    <!--        <a href="<?php if($pageno <= 1){ echo '#'; } else { echo "?pageno=".($pageno - 1); } ?>">Prev</a>-->
    <!--    </li>-->
    <!--    <li class="<?php if($pageno >= $total_pages){ echo 'disabled'; } ?>">-->
    <!--        <a  href="<?php if($pageno >= $total_pages){ echo '#'; } else { echo "?pageno=".($pageno + 1); } ?>">Next</a>-->
    <!--    </li>-->
    <!--    <li><a  href="?pageno=<?php echo $total_pages; ?>">Last</a></li>-->
    <!--</ul> -->
                           
                            </div>
                        
                        
                        
                    </div>
                   
                  
                   
                   
                </div>
            </div>

        </main>
        <!-- page-content" -->
    </div>
    <!-- page-wrapper -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>
    <script src="style.js"></script>
    
    <script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#myTable tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

</body>

</html>







