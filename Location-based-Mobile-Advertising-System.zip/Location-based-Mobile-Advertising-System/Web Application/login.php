<?php
include 'config.php';


$name=$_POST['un'];
$pass=$_POST['pass'];


$sql=mysqli_query($conn,"SELECT * FROM register WHERE uname='$name' AND pass= '$pass'");



 $rows = mysqli_num_rows($sql);
     
    if($rows>0) { 
        //echo "success"; 
session_start();
  $_SESSION['un'] = $name; 

header("location:home.php");
    }
    else  {
        echo "Invalid Details"; 
    }

?>