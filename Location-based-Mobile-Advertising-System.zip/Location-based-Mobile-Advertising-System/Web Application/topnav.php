<div id="app" class="container" style="
    max-width: 100%;padding:0px">
  <nav class="navbar navbar-expand-md navbar-light bg-dark">
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    
    <ul class="navbar-nav mr-auto">
      <!--<li class="nav-item active">-->
      <!--  <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>-->
      <!--</li>-->
      <!--<li class="nav-item">-->
      <!--  <a class="nav-link" href="#">Features</a>-->
      <!--</li>-->
      <!--<li class="nav-item">-->
      <!--  <a class="nav-link" href="#">Pricingg</a>-->
      <!--</li>-->
    </ul>
    <ul class="navbar-nav">
        
        <li class="nav-item">
        <a class="nav-link" href="home.php" style="color:white">home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"  style="color:white">About</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="home.php"  style="color:white">Jobs</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"  style="color:white">Profile</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"  style="color:white">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="logout.php"  style="color:white">Logout</a>
      </li>
      
    </ul>
  </nav>
</div>