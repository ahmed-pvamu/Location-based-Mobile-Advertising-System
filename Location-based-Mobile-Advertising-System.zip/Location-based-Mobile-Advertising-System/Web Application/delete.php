<?php
include 'config.php';

$id=$_GET['id'];

//echo $id;



// sql to delete a record
$sql = "DELETE FROM jobs WHERE Id=$id";

if ($conn->query($sql) === TRUE) {
   // echo "Record deleted successfully";
    header("Location:home.php");
} else {
    echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>