package com.adds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserLoginActivity extends AppCompatActivity {
    EditText et_user, et_pwd;
    Button btn_add;
    TextView textView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userlogin);

        getSupportActionBar().setTitle("User Login");

        et_user = (EditText) findViewById(R.id.et_user);
        et_pwd = (EditText) findViewById(R.id.et_pwd);
        btn_add = (Button) findViewById(R.id.btn_add);
        textView = (TextView) findViewById(R.id.tv_reg);
        View.OnClickListener obj = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
              // String str = et_user.getText().toString();
                //String str1 = et_pwd.getText().toString();
                if(et_user.getText().toString().isEmpty()){
                    Toast.makeText(UserLoginActivity.this, "User Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_pwd.getText().toString().isEmpty()){
                    Toast.makeText(UserLoginActivity.this, "Password should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                submitData();
                //Toast.makeText(UserLoginActivity.this, str1, Toast.LENGTH_SHORT).show();
                //Intent obj1 = new Intent(UserLoginActivity.this, UserDashboardActivity.class);
                //startActivity(obj1);


            }
        };
        btn_add.setOnClickListener(obj);
        View.OnClickListener obj2 = new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str2 = textView.getText().toString();
                Toast.makeText(UserLoginActivity.this, str2, Toast.LENGTH_SHORT).show();
                Intent obj1 = new Intent(UserLoginActivity.this, UserRegistrationActivity.class);
                startActivity(obj1);
            }
        };
        textView.setOnClickListener(obj2);

    }
    ProgressDialog progressDialog;
    private void submitData(){

        String str1=et_user.getText().toString();
        String str2=et_pwd.getText().toString();

        progressDialog = new ProgressDialog(UserLoginActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        RetrifitAPI service = RetrofitInstance.getRetrofitInstance().create(RetrifitAPI.class);
        Call<ResponseData> call = service.userlogin(str1,str2);

        call.enqueue(new Callback<ResponseData>() {
            @Override
            public void onResponse(Call<ResponseData> call, Response<ResponseData> response) {
                progressDialog.dismiss();
                if(response.body().status.equals("true")){
                    Toast.makeText(UserLoginActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                    startActivity(new Intent(UserLoginActivity.this, UserDashboardActivity.class));
                }else{
                    Toast.makeText(UserLoginActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ResponseData> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(UserLoginActivity.this,t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}

