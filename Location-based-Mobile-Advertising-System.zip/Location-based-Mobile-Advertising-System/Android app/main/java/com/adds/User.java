package com.adds;

import com.google.gson.annotations.SerializedName;

public class User {
    @SerializedName("ads_name")
    private
    String ads_name ;

    @SerializedName("ads_desc")
    private
    String ads_desc ;

    @SerializedName("mobile")
    private
    String mobile ;

    @SerializedName("price")
    private
    int price ;

    @SerializedName("advertiser_name")
    private
    String advertiser_name;

    @SerializedName("status")
    private
    String status;

    User(String ads_name,String ads_desc,String mobile,int price,String advertiser_name){

        this.setAds_name(ads_name);
        this.setAds_desc(ads_desc);
        this.setMobile(mobile);
        this.setAdvertiser_name(advertiser_name);
        this.setPrice(price);
        this.setStatus(getStatus());
    }

    public String getAds_name() {
        return ads_name;
    }

    public void setAds_name(String ads_name) {
        this.ads_name = ads_name;
    }

    public String getAds_desc() {
        return ads_desc;
    }

    public void setAds_desc(String ads_desc) {
        this.ads_desc = ads_desc;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getAdvertiser_name() {
        return advertiser_name;
    }

    public void setAdvertiser_name(String advertiser_name) {
        this.advertiser_name = advertiser_name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
