package com.adds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdsPostAdActivity extends AppCompatActivity {
    EditText et_ad_name,et_des,et_price,et_contact,et_adver_name;
    Button btn_add;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_post_ads);

        et_ad_name=(EditText)findViewById(R.id.et_ad_name);
        et_des=(EditText)findViewById(R.id.et_des);
        et_price=(EditText)findViewById(R.id.et_price);
        et_contact=(EditText)findViewById(R.id.et_contact);
        et_adver_name=(EditText)findViewById(R.id.et_adver_name);
        btn_add=(Button)findViewById(R.id.btn_add);

        View.OnClickListener obj=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(et_ad_name.getText().toString().isEmpty()){
                    Toast.makeText(AdsPostAdActivity.this, " Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_des.getText().toString().isEmpty()){
                    Toast.makeText(AdsPostAdActivity.this, "Description should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_price.getText().toString().isEmpty()){
                    Toast.makeText(AdsPostAdActivity.this, "Prise should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_contact.getText().toString().isEmpty()){
                    Toast.makeText(AdsPostAdActivity.this, "Contact should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_adver_name.getText().toString().isEmpty()){
                    Toast.makeText(AdsPostAdActivity.this, "Advertiser Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                submitData();
            }
        };
        btn_add.setOnClickListener(obj);

    }
    ProgressDialog progressDialog;
    private void submitData(){

        String str1=et_ad_name.getText().toString();
        String str2=et_des.getText().toString();
        String str3=et_price.getText().toString();

        String str4=et_contact.getText().toString();

        String str5=et_adver_name.getText().toString();

        progressDialog = new ProgressDialog(AdsPostAdActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        RetrifitAPI service = RetrofitInstance.getRetrofitInstance().create(RetrifitAPI.class);
        Call<ResponseData> call = service.adpost(str1,str2,Integer.parseInt(str3),str4,str5);

        call.enqueue(new Callback<ResponseData>() {
            @Override
            public void onResponse(Call<ResponseData> call, Response<ResponseData> response) {
                progressDialog.dismiss();
                if(response.body().status.equals("true")){
                    Toast.makeText(AdsPostAdActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                    finish();
                }else{
                    Toast.makeText(AdsPostAdActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ResponseData> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AdsPostAdActivity.this,t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}


