package com.adds;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RetrifitAPI {
    @GET("/LocationAds/user_reg.php")
    Call<ResponseData> userreg(
            @Query("name") String name,
            @Query("email") String email,
            @Query("phno") String phno,
             @Query("uname") String uname,
            @Query("pwd") String password
    );
    @GET("/LocationAds/ads_reg.php")
    Call<ResponseData> adsreg(
            @Query("name") String name,
            @Query("email") String email,
            @Query("phno") String phoneno,
            @Query("uname") String username,
            @Query("pwd") String password
    );
    @GET("/LocationAds/ads_login.php")
    Call<ResponseData> adslogin(
            @Query("uname") String uname,
            @Query("pwd") String pwd
    );
    @GET("/LocationAds/user_login.php")
    Call<ResponseData> userlogin(
            @Query("uname") String uname,
            @Query("pwd") String pwd


    );
    @GET("/LocationAds/insert_posts.php")
    Call<ResponseData> adpost(
            @Query("ads_name") String ads_name,
            @Query("ads_desc") String ads_desc,
            @Query("price") int price,
            @Query("mobile") String mobile,
            @Query("advertiser_name") String advertiser_name
    );

}

