package com.adds;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface EndPointUrl {

    @GET("LocationAds/getPosts.php")
    Call<List<User>> editpost();
}
