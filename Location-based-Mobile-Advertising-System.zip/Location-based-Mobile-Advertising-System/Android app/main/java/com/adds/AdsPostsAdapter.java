package com.adds;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class AdsPostsAdapter extends BaseAdapter {
    TextView tv_name,tv_ad_des,tv_price,tv_contact,et_adver_name;
    List<User> ar;
    Context cnt;
    public AdsPostsAdapter(List<User> ar, Context cnt){
        this.ar=ar;
        this.cnt=cnt;
    }
    @Override
    public int getCount() {
        return ar.size();
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        LayoutInflater obj1 = (LayoutInflater)cnt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View obj2=obj1.inflate(R.layout.ads_row_posts,null);
        User obj3=(ar.get(i));

        tv_name=(TextView)obj2.findViewById(R.id.tv_name);
        tv_name.setText("Name : "+obj3.getAds_name());


        tv_ad_des=(TextView)obj2.findViewById(R.id.tv_ad_des);
        tv_ad_des.setText( "Description :"+ obj3.getAds_desc());


        tv_price=(TextView)obj2.findViewById(R.id.tv_price);
        tv_price.setText("Price :"+obj3.getPrice());

        tv_contact=(TextView)obj2.findViewById(R.id.tv_contact);
        tv_contact.setText("Contact :"+ obj3.getMobile());

        et_adver_name=(TextView)obj2.findViewById(R.id.et_adver_name);
        et_adver_name.setText("Advertiser Name :" + obj3.getAdvertiser_name());

        return obj2;
    }
}
