package com.adds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UserRegistrationActivity extends AppCompatActivity {
    EditText et_mail,name,et_phnum,et_uname,et_pwd;
    Button btn_reg;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);
        getSupportActionBar().setTitle("User Registration");


        btn_reg=(Button) findViewById(R.id.btn_add);
        name=(EditText)findViewById(R.id.et_user);
        et_phnum=(EditText)findViewById(R.id.et_phnno);
        et_mail=(EditText)findViewById(R.id.et_email);
        et_uname=(EditText)findViewById(R.id.et_username);
        et_pwd=(EditText)findViewById(R.id.et_password);

        View.OnClickListener obj=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //String str=btn_reg.getText().toString();
               // Toast.makeText(UserRegistrationActivity.this,str,Toast.LENGTH_SHORT).show();
                if(name.getText().toString().isEmpty()){
                    Toast.makeText(UserRegistrationActivity.this, " Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_mail.getText().toString().isEmpty()){
                    Toast.makeText(UserRegistrationActivity.this, "Email should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_phnum.getText().toString().isEmpty()){
                    Toast.makeText(UserRegistrationActivity.this, "Phone Number should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_uname.getText().toString().isEmpty()){
                    Toast.makeText(UserRegistrationActivity.this, "User Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_pwd.getText().toString().isEmpty()){
                    Toast.makeText(UserRegistrationActivity.this, "User Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                submitData();
               // Intent obj1=new Intent(UserRegistrationActivity.this, UserLoginActivity.class);
               // startActivity(obj1);
            }
        };
        btn_reg.setOnClickListener(obj);
    }
    ProgressDialog progressDialog;
    private void submitData(){
        String str=name.getText().toString();
        String str1=et_mail.getText().toString();
        String str2=et_phnum.getText().toString();
        String str3=et_uname.getText().toString();
        String str4=et_pwd.getText().toString();

        progressDialog = new ProgressDialog(UserRegistrationActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        RetrifitAPI service = RetrofitInstance.getRetrofitInstance().create(RetrifitAPI.class);
        Call<ResponseData> call = service.userreg(str,str1,str2,str3,str4);

        call.enqueue(new Callback<ResponseData>() {
            @Override
            public void onResponse(Call<ResponseData> call, Response<ResponseData> response) {
                progressDialog.dismiss();
                if(response.body().status.equals("true")){
                    Toast.makeText(UserRegistrationActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                    startActivity(new Intent(UserRegistrationActivity.this, UserLoginActivity.class));
                }else{
                    Toast.makeText(UserRegistrationActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ResponseData> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(UserRegistrationActivity.this,t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}


