package com.adds;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdsEditAdsActivity extends AppCompatActivity {
    ListView listView;
    List<User> a1;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads_edit_ads);

        listView=(ListView)findViewById(R.id.list_view);

        progressDialog = new ProgressDialog(AdsEditAdsActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        EndPointUrl service = RetrofitInstance.getRetrofitInstance().create(EndPointUrl.class);
        Call<List<User>> call = service.editpost();
        call.enqueue(new Callback<List<User>>() {
            @Override
            public void onResponse(Call<List<User>> call, Response<List<User>> response) {

                progressDialog.dismiss();
                a1=response.body();
                listView.setAdapter(new AdsPostsAdapter(a1,AdsEditAdsActivity.this));
            }

            @Override
            public void onFailure(Call<List<User>> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AdsEditAdsActivity.this, ""+t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });


    }
}
