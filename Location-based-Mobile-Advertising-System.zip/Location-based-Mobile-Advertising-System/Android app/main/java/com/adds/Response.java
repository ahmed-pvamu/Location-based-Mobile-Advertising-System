package com.adds;

import com.google.gson.annotations.SerializedName;

public class Response {
    @SerializedName("message")
    String message;

    @SerializedName("status")
    String status;
}
