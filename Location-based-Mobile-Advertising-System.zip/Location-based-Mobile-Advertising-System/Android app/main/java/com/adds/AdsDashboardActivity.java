package com.adds;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class AdsDashboardActivity extends AppCompatActivity {
    Button btn_post,btn_editads,btn_editprofile,btn_logout;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads_dashboard);
        getSupportActionBar().setTitle("Ads Dashboard");

        btn_post=(Button)findViewById(R.id.postad);

        btn_editads=(Button)findViewById(R.id.editads);

        btn_editprofile=(Button)findViewById(R.id.editprofile);

        btn_logout=(Button)findViewById(R.id.logout);

        View.OnClickListener obj1=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj1=new Intent(AdsDashboardActivity.this,AdsPostAdActivity.class);
                startActivity(obj1);

            }
        };
        btn_post.setOnClickListener(obj1);

        View.OnClickListener obj2=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj2=new Intent(AdsDashboardActivity.this,AdsEditAdsActivity.class);
                startActivity(obj2);

            }
        };
        btn_editads.setOnClickListener(obj2);

        View.OnClickListener obj3=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj3=new Intent(AdsDashboardActivity.this,AdsEditProfileActivity.class);
                startActivity(obj3);

            }
        };
        btn_editprofile.setOnClickListener(obj3);

        View.OnClickListener obj4=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj4=new Intent(AdsDashboardActivity.this,AdsLogoutActivity.class);
                startActivity(obj4);

            }
        };
        btn_logout.setOnClickListener(obj4);



    }
}
