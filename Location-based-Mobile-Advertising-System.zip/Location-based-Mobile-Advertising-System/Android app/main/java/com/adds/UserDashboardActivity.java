package com.adds;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class UserDashboardActivity extends AppCompatActivity {
    Button btn_viewads,btn_editprofile,btn_logout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard);
        getSupportActionBar().setTitle("User Dashboard");
        btn_viewads=(Button)findViewById(R.id.viewads);
        btn_editprofile=(Button)findViewById(R.id.editprofile);
        btn_logout=(Button)findViewById(R.id.logout);

        final View.OnClickListener obj1=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(UserDashboardActivity.this,UserViewAdsActivity.class);
                startActivity(obj);
            }
        };
        btn_viewads.setOnClickListener(obj1);

        View.OnClickListener obj2=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(UserDashboardActivity.this,UserEditProfileActivity.class);
                startActivity(obj);
            }
        };
        btn_editprofile.setOnClickListener(obj2);

        View.OnClickListener obj3=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent obj=new Intent(UserDashboardActivity.this,UserLogoutActivity.class);
                startActivity(obj);
            }
        };
        btn_logout.setOnClickListener(obj3);


    }
}
