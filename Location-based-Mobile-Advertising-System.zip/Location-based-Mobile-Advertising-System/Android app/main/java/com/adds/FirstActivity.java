package com.adds;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class FirstActivity extends AppCompatActivity {
    Button btnadd,btnuser;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first);
        btnadd=(Button)findViewById(R.id.btnad);
        btnuser=(Button)findViewById(R.id.btnuser);



        View.OnClickListener obj1=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str="Button One";
                Toast.makeText(FirstActivity.this,str,Toast.LENGTH_SHORT).show();
                Intent obj3=new Intent(FirstActivity.this,AdvertiserLoginActivity.class);
                startActivity(obj3);

            }
        };
        btnadd.setOnClickListener(obj1);
        View.OnClickListener obj2=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String str="Button Two";
                Toast.makeText(FirstActivity.this,str,Toast.LENGTH_SHORT).show();
                Intent obj4=new Intent(FirstActivity.this,UserLoginActivity.class);
                startActivity(obj4);
            }
        };
        btnuser.setOnClickListener(obj2);

    }
}


