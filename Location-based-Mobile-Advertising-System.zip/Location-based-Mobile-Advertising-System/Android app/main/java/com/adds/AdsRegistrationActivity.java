package com.adds;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdsRegistrationActivity extends AppCompatActivity {
    Button btn_adsreg;
    EditText et_mail,name,et_phnum,et_uname,et_pwd;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ads_registration);
        getSupportActionBar().setTitle("Ads Registration");

        name=(EditText)findViewById(R.id.et_user);
        et_phnum=(EditText)findViewById(R.id.et_phnno);
        et_mail=(EditText)findViewById(R.id.et_email);
        et_uname=(EditText)findViewById(R.id.et_username);
        et_pwd=(EditText)findViewById(R.id.et_password);
        btn_adsreg=(Button)findViewById(R.id.btn_add);

        View.OnClickListener obj=new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent obj1=new Intent(AdsRegistrationActivity.this,AdvertiserLoginActivity.class);
               // startActivity(obj1);
                if(name.getText().toString().isEmpty()){
                    Toast.makeText(AdsRegistrationActivity.this, " Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_mail.getText().toString().isEmpty()){
                    Toast.makeText(AdsRegistrationActivity.this, "Email should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_phnum.getText().toString().isEmpty()){
                    Toast.makeText(AdsRegistrationActivity.this, "Phone Number should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_uname.getText().toString().isEmpty()){
                    Toast.makeText(AdsRegistrationActivity.this, "User Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                if(et_pwd.getText().toString().isEmpty()){
                    Toast.makeText(AdsRegistrationActivity.this, "User Name should not be empty", Toast.LENGTH_SHORT).show();
                    return;
                }
                submitData();

            }
        };
        btn_adsreg.setOnClickListener(obj);
    }
    ProgressDialog progressDialog;
    private void submitData(){
        String str=name.getText().toString();
        String str1=et_mail.getText().toString();
        String str2=et_phnum.getText().toString();
        String str3=et_uname.getText().toString();
        String str4=et_pwd.getText().toString();

        progressDialog = new ProgressDialog(AdsRegistrationActivity.this);
        progressDialog.setMessage("Loading....");
        progressDialog.show();

        RetrifitAPI service = RetrofitInstance.getRetrofitInstance().create(RetrifitAPI.class);
        Call<ResponseData> call = service.adsreg(str,str1,str2,str3,str4);

        call.enqueue(new Callback<ResponseData>() {
            @Override
            public void onResponse(Call<ResponseData> call, Response<ResponseData> response) {
                progressDialog.dismiss();
                if(response.body().status.equals("true")){
                    Toast.makeText(AdsRegistrationActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                    startActivity(new Intent(AdsRegistrationActivity.this, AdvertiserLoginActivity.class));
                }else{
                    Toast.makeText(AdsRegistrationActivity.this,response.body().message,Toast.LENGTH_LONG).show();
                }

            }

            @Override
            public void onFailure(Call<ResponseData> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AdsRegistrationActivity.this,t.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }
}


